create definer = admin@`%` event user_login_attempts_archive on schedule
    every '24' HOUR
        starts '2022-03-31 02:00:00'
    enable
    do
    BEGIN
	INSERT INTO `befiler_prod_archive`.`um_user_login_attempts`
	SELECT * FROM `befiler_prod`.`um_user_login_attempts` -- [database name]
	WHERE DATE(created_date) < CURRENT_DATE() - INTERVAL 
		(SELECT `settings`.`record_value` 
		FROM `befiler_prod`.`settings` -- [database name]
		WHERE `record_type` =  34) DAY;
	DELETE FROM `befiler_prod`.`um_user_login_attempts` -- [database name]
	WHERE DATE(created_date) < CURRENT_DATE() - INTERVAL 
		(SELECT `settings`.`record_value` 
		FROM `befiler_prod`.`settings` -- [database name]
		WHERE `record_type` =  34) DAY;
	END;

